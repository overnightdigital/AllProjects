

import java.io.*;
import java.net.*;

public class ServerThread extends Thread{

	public Socket socket = null;
	
	public boolean accountSet = false;
	
	public Server server;
	
	public ObjectOutputStream output;
	
	public ObjectInputStream input;
	
	private int isBoardChecked = 0;
	
	public boolean mapCheck = false;
	
	
	//final static long serialVersionUID = 102;
	
	boolean test = true;
	
	public ServerThread() {
		
	}
	
	// Constructor which receives the server as this object so it can access all server side methods like checkPlayerTurn
	// and also a socket from the client
	
	ServerThread(Socket socket, Server server){
		this.socket = socket;
		this.server = server;
		
		try {
		
			output = new ObjectOutputStream(socket.getOutputStream());
			input = new ObjectInputStream(socket.getInputStream());
		}
		catch(IOException ioException) 
		{
			ioException.printStackTrace();
		}
	}
	
	// The run methos is the core method in which all moves are made and checked // The threads calls the server Method check
	// which is then being checked server sided
	
	@Override
	public void run() {
		try {
		Message message = null;
			
			while((message = (Message)input.readObject())!=null)
			{
				
				if(!accountSet && message.PlayerID != 0) {
					if(this == server.PlayerOne) {
						server.PlayerID_1 = message.PlayerID;
						message.PlayerID_1 = message.PlayerID;
						UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, -1);
						server.users.add(u);
					}
					
					if(this == server.PlayerTwo) {
						server.PlayerID_2 = message.PlayerID;
						message.PlayerID_2 = message.PlayerID;
						UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, -1);
						server.users.add(u);
					}
					accountSet = true;
					server.setFirstPlayer();
				}
				if(isBoardChecked < 200) {
					
				if(!mapCheck) {	
					server.logger.info("Checking Map ...");
					if(!server.checkBoard(message)) {
						server.logger.info("!!!!!!!!!!!!!!!!!!!!!! MAP FAILED !!!!!!!!!!!!!!!!!!!!");
                    	message.lost_Player = message.PlayerID;
                    	message.stopGame = true;
                    	}
					mapCheck = true;
					}
					server.logger.info("Message Received From Client And Deligated To Server");
					server.updateBoard(message);
					isBoardChecked++;
					
				}
				
				if(server.isPlayerTurnAndChangePlayer(this))
				{
					server.logger.info(" Player Request To Move And Approved :  " + message.PlayerID);
                    if(!server.checkMove(message)) {
                    	message.lost_Player = message.PlayerID;
                    	message.stopGame = true;
                    }
					server.updateBoard(message);
					server.logger.info("ServerThread Sent New Player Position");
				}else {
					server.logger.info("Player Tried To Play But Not His Turn : " + message.PlayerID);
				}

			
			} 
		
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
		}
		catch(IOException ioException) 
		{
			server.logger.info("ServerThread Exception");
			ioException.printStackTrace();
		} finally {
			
				try {
					socket.close();
				} catch(IOException ioException) {
					ioException.printStackTrace();
			}
			
		}
	}
	
	// this method just sends the message to his adequate client with the method writeObject

	
	public void sendMessage(Message message)
	{
		try {
			
			if(message != null) {
				output.writeObject(message);
				output.flush();
			}
			
		}
		catch(IOException ioException) {
			ioException.printStackTrace();
		}

	}
	
}