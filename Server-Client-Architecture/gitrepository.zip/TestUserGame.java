import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;

import org.junit.Test;

public class TestUserGame {

	@Test
	public void test() {
		CurrentGame g = new CurrentGame(1, "77", "00", "76", "N", "?", 1);
		
		assertThat(g, is(not(nullValue())));
	}

}
