import static org.junit.Assert.*;

import org.junit.Test;

public class TestServerCheckMoveCount {

	@Test
	public void test() {
		Server test = new Server();
		Message message = new Message();
		test.moveCount = 10;
		assertEquals(test.checkMoveCount(message), true);
	}

}
