import static org.junit.Assert.*;

import org.junit.Test;

public class TestServerGenerateGold {

	@Test
	public void test() {
		Server test = new Server();
		ViewMap map = new ViewMap(0,0);
		Message message = new Message();
		message.Map = map;
		test.generateGold(message);
		assertEquals(message.Map.coordinates[message.xPositionPlayerTreasureOne][message.yPositionPlayerTreasureOne], 1, 2);
	}

}
