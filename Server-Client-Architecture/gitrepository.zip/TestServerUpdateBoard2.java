import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.junit.Test;

public class TestServerUpdateBoard2 {

	@Test
	public void test() {
		ViewMap map = new ViewMap(0,1);
		ViewMap map2 = new ViewMap(0,2);
		Message message = new Message();
		Message message2 = new Message();
		message.Map = map;
		message2.Map = map2;
		message.PlayerID = 1;
		message2.PlayerID = 2;
		Server test = new Server();
		test.PlayerID_1 = 1;
		test.PlayerID_2 = 2;
		test.whatPlayer = 1;
		test.updateBoard(message);
		test.updateBoard(message2);
		assertThat(test.PlayerID_1, is(test.whatPlayer));
	}

}
