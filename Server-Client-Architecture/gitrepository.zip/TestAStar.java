import static org.junit.Assert.*;

import org.junit.Test;

public class TestAStar {

	@Test
	public void test() {
		AStar test = new AStar();
		int[][] blocked = new int[8][8];
		blocked[0][6] = -1;
		blocked[1][6] = -1;
		blocked[1][7] = -1;
		boolean result = test.test(0, 8, 8, 0, 0, 0, 7, blocked);
		assertEquals(result, false);
	}

}
