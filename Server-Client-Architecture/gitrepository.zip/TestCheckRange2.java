import static org.junit.Assert.*;

import org.junit.Test;

public class TestCheckRange2 {

	@Test
	public void test() {
		ViewMap map = new ViewMap(0,0);
		Message message = new Message();
		message.Map = map;
		message.xNewPos = 10;
		message.yNewPos = 4;
		Server test = new Server();
		boolean result = test.checkRange(message);
		assertEquals(result, false);
	}

}
