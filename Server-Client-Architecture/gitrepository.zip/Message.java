import java.io.Serializable;

public class Message implements Serializable {
	
	public int PlayerID;
	
	public int PlayerID_1;
	
	public int PlayerID_2;
	
	public ViewMap Map;

	public int xPositionPlayerOne = -99;
	
	public int yPositionPlayerOne = -99;
	
	public int xPositionPlayerTwo = -99;
	
	public int yPositionPlayerTwo = -99;
	
	public int xPositionPlayerCastleOne;
	
	public int yPositionPlayerCastleOne;
	
	public int xPositionPlayerCastleTwo;
	
	public int yPositionPlayerCastleTwo;
	
	public int xPositionPlayerTreasureOne;
	
	public int yPositionPlayerTreasureOne;
	
	public int xPositionPlayerTreasureTwo;
	
	public int yPositionPlayerTreasureTwo;
	
	public int xNewPos = -99;
	
	public int yNewPos = -99;
	
	public boolean playersOnlineAndPlayerOneStarts = false;
	
	boolean won_lost_P1 = false;
	
	public int won_Player = 0;
	
	public int lost_Player = 0;
	
	boolean won_lost_P2 = false;
	
	boolean stopGame = false;
	
	final static long serialVersionUID = 1L;
	
	
	public Message()
	{
		
	}
	
	public Message(int PlayerID)
	{
		this.PlayerID = PlayerID;
	}
	
	public Message(ViewMap viewMap)
	{
		this.Map = viewMap;
	}
	
	
	
}
