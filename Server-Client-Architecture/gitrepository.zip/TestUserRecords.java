import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.Test;

public class TestUserRecords {

	@Test
	public void test() {
		UserRecords u = new UserRecords(1, 0, 0, 0, 0);
		
		assertThat(u, is(not(nullValue())));
	}

}
