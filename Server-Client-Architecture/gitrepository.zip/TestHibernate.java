import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.util.Vector;

import org.junit.Test;

public class TestHibernate {

	@Test
	public void test() {
		Hibernate test = new Hibernate();
		UserRecords u = new UserRecords(1, 0, 0, 0, 0);
		UserRecords u2 = new UserRecords(2, 0, 0, 0, 0);
		UserRecords u3 = new UserRecords(3, 0, 0, 0, 0);
		CurrentGame g = new CurrentGame(1, "76", "00", "77", "N", "?", 1);
		CurrentGame g2 = new CurrentGame(2, "56", "00", "66", "N", "?", 2);
		CurrentGame g3 = new CurrentGame(3, "45", "00", "55", "N", "?", 3);
		test.users = new Vector<UserRecords>();
		test.moves = new Vector<CurrentGame>();
		test.users.add(u);
		test.users.add(u2);
		test.users.add(u3);
		test.moves.add(g);
		test.moves.add(g2);
		test.moves.add(g3);
		Vector<UserRecords> usersTest = new Vector<UserRecords>();
		Vector<CurrentGame> movesTest = new Vector<CurrentGame>();
		usersTest.add(u);
		usersTest.add(u2);
		usersTest.add(u3);
		movesTest.add(g);
		movesTest.add(g2);
		movesTest.add(g3);
		test.saveCurrentGame(movesTest);
		test.saveUser(usersTest);
		test.print(1, 2);
		assertEquals(usersTest, test.users);
		assertEquals(movesTest, test.moves);
	}

}
