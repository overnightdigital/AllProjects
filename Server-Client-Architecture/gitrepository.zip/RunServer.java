

import java.io.*;

public class RunServer {
	
public static void main(String[] args) throws IOException {
		
		new Server().runServer();
		
	}

}
