import org.hibernate.*;
import java.io.PrintWriter;
import org.hibernate.cfg.Configuration;
import java.util.Vector;


public class Hibernate {
	
	private SessionFactory sessionFactory = null;
	private SessionFactory configureSessionFactory() throws HibernateException {
		sessionFactory = new Configuration()
				.configure()
				.buildSessionFactory();
		return sessionFactory;
	}
	
	public Vector<UserRecords> users;
	
	public Vector<CurrentGame> moves;
	
	
	
	public void saveUser(Vector<UserRecords> v) {
		configureSessionFactory();
		Session session = null;
		Transaction tx = null;
		
		this.users = v;
		
		try {
			
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			for(UserRecords r : v) {
			
			//UserRecords u;
			
			//u = new UserRecords(PlayerID, GamesPlayed, GamesWon, NoOfGamesPlayerMadeErrors, Raiting);
			if((UserRecords) session.get(UserRecords.class, r.PlayerID) == null) {
				System.out.println("------------------------" + r.PlayerID);
				session.saveOrUpdate(r);
				session.flush();
			
			}else {
				System.out.println("++++++++++++++++++++++++++++" + r.PlayerID);
				r = (UserRecords) session.get(UserRecords.class, r.PlayerID);
				r.GamesPlayed++;
				if(r.Raiting == 0) {
					r.NoOfGamesPlayerMadeErrors++;
				}else if(r.Raiting == 5){
					r.GamesWon++;
				}
				session.saveOrUpdate(r);
				session.flush();
			
				}
			
			}
			tx.commit();
			
		} catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if(session != null) {
				session.close();
			}
		}
	}
	
	public void saveCurrentGame(Vector<CurrentGame> v) {
		
		configureSessionFactory();
		Session session = null;
		Transaction tx = null;
		
		this.moves = v;
		
		try {
			
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			for(CurrentGame g : v) {
			
			//CurrentGame g = (CurrentGame) session.get(CurrentGame.class, MoveID);
			//if(g == null) {
			//CurrentGame	g = new CurrentGame(MoveID, StartPos, EndPos, MovePlayed, Direction, Discovery);	
			//}else {
			//	g.MoveID++;
			//}
			//session.saveOrUpdate(g);
			session.save(g);
				session.flush();
				
			}	
				
				tx.commit();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if(session != null) {
				session.close();
			}
		}
		
	}
	
	public void saveUserGame(int MoveID, int PlayerID, int GameID) {
		
		configureSessionFactory();
		Session session = null;
		Transaction tx = null;
		
		try {
			
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			UserGame ug = new UserGame(MoveID, PlayerID, GameID);
				session.saveOrUpdate(ug);
				session.flush();
				tx.commit();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if(session != null) {
				session.close();
			}
		}
		
	}
	
	public void print(int id1, int id2) {
		
		try {
		
		PrintWriter pw = new PrintWriter("gameFile.txt");
		
		configureSessionFactory();
		Session session = null;
		Transaction tx = null;
		
		
		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		
		
		UserRecords u = (UserRecords) session.get(UserRecords.class, id1);
		UserRecords u2 = (UserRecords) session.get(UserRecords.class, id2);
		
		pw.println();
		pw.println("Player 1 : ");
		pw.println(u);
		pw.println();
		pw.println("Player 2 : ");
		pw.println(u2);
		
		
		pw.println();
		pw.println("Game protocol : ");
		pw.println();
		
		for(CurrentGame g : moves){
			pw.println(g);
			pw.println();
       }
		
	    pw.close();
	    
			} catch(Exception e) {
			e.printStackTrace();
		}
	}
	/*
	public static void main(String[] args) {
		Hibernate save = new Hibernate();
		save.saveUser(123, 0, 0, 0, 5);
		save.saveUser(47, 0, 0, 0, 0);
		save.saveUser(568, 5, 2, 3, 0);
		save.saveCurrentGame(99, 00, 00, 01, "Right", "Land");
		save.saveCurrentGame(100, 00, 00, 02, "Right", "Land");
		save.saveCurrentGame(101, 00, 00, 12, "Right", "Land");
		save.saveUserGame(99, 123, 18);
		save.saveUserGame(100, 568, 18);
		save.saveUserGame(101, 128, 18);
		save.saveUser(123, 0, 0, 0, 5);
		save.saveUser(568, 5, 2, 3, 0);
	}
	*/

}
