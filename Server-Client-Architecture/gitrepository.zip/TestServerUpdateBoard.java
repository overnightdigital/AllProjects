import static org.junit.Assert.*;

import org.junit.Test;
import static org.hamcrest.CoreMatchers.is;

public class TestServerUpdateBoard {

	@Test
	public void test() {
		ViewMap map = new ViewMap(0,1);
		Message message = new Message();
		message.Map = map;
		message.PlayerID = 1;
		Server test = new Server();
		test.PlayerOneOnline = true;
		test.updateBoard(message);
		assertThat(test.map.coordinates, is(map.coordinates));
	}

}
