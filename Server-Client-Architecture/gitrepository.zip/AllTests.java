import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestAStar.class, TestAStar2.class, TestCheckRange2.class, TestServer.class,
		TestServerCheckRange.class, TestServerCheckWater.class, TestServerUpdateBoard.class,
		TestServerUpdateBoard2.class, TestUserRecords.class, TestUserGame.class, TestServerCheckMoveCount.class, 
		TestServerGenerateGold.class, TestHibernate.class})

public class AllTests {

}
