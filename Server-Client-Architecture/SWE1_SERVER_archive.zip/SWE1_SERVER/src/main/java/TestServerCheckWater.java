import static org.junit.Assert.*;

import org.junit.Test;

public class TestServerCheckWater {

	@Test
	public void test() {
		ViewMap map = new ViewMap(0,0);
		Message message = new Message();
		Server test = new Server();
		message.Map = map;
		test.map.coordinates[4][4] = 1;
		message.xNewPos = 4;
		message.yNewPos = 4;
		boolean result = test.checkWater(message);
		assertEquals(result, false);
	}

}
