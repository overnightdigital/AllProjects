import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


@Entity
@Table(name="UserGame")
public class UserGame implements Serializable {

	@Id
	@Column(name="MoveID")
	int MoveID = 0;
	
	@Id
	@Column(name="PlayerID")
	int PlayerID = 0;
	
	@Id
	@Column(name="GameID")
	int GameID = 0;
	
	final static long serialVersionUID = 102;
	
	UserGame() {}
	
	UserGame(int MoveID, int PlayerID, int GameID) {
		this.MoveID = MoveID;
		this.PlayerID = PlayerID;
		this.GameID = GameID;
	}
	
	@Override
	public String toString() {
		return "happy";
	}
}
