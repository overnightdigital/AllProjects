import javax.persistence.*;

@Entity
@Table(name="UserRecords")
public class UserRecords {
	
	@Id
	@Column(name="PlayerID")
	int PlayerID = 0;
	
	@Column(name="GamesPlayed")
	int GamesPlayed = 0;
	
	@Column(name="GamesWon")
	int GamesWon = 0;
	
	@Column(name="NoOfGamesPlayerMadeErrors")
	int NoOfGamesPlayerMadeErrors = 0;
	
	@Column(name="Raiting")
	int Raiting = 0;
	//raiting 0 lost / raiting 5 won
	
	
	UserRecords() {}
	
	UserRecords(int PlayerID, int GamesPlayed, int GamesWon, int NoOfGamesPlayerMadeErrors, int Raiting){
		this.PlayerID = PlayerID;
		this.GamesPlayed = GamesPlayed;
		this.GamesWon = GamesWon;
		this.NoOfGamesPlayerMadeErrors = NoOfGamesPlayerMadeErrors;
		this.Raiting = Raiting;
		
	}
	
	@Override
	public String toString() {
		return " - PlayerID : " + PlayerID + " | GamesPLayed : " + GamesPlayed + " | GamesWon : " + GamesWon + " | NoOfGamesPlayerMadeErrors : " + NoOfGamesPlayerMadeErrors + " | Raiting : " + Raiting + "-";
	}

}
