import static org.junit.Assert.*;

import org.junit.Test;

public class TestServer {

	@Test
	public void test() {
		ViewMap map = new ViewMap(0,0);
		Message message = new Message();
		message.Map = map;
		Server test = new Server();
		boolean result = test.checkBoard(message);
		assertEquals(result, true);
	}

}
