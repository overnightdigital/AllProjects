
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Vector;
import java.awt.Color;
import java.util.logging.*;


public class Server{
	
	Logger logger = Logger.getLogger("Server");
	
	FileHandler fh;
	
	public int whatPlayer = 0; //PlayerID tells what player plays // if 0 noone plays
	
	public static final int PORT = 35648; // Port number
	
    private static final int DIMENSION_X = 8; // X axis
	
	private static final int DIMENSION_Y = 8; // Y axis
	
	private static final int MIN_VALUE_LAND = 5; // Min Amount of Land areas / value normaly in ViewMap but needed here also to check Map
	
	private static final int MIN_VALUE_MOUNTAIN = 3; // Min Value for Mountain / same as Land
	
	private static final int MIN_VALUE_WATER = 4; // Same as Land
	
	private static final int MAX_MOVES = 40; // Max Amount of Moves that can be made in a game
	
	public int PlayerID_1 = 0; // PlayerID when set as 0 Player is not online / any other number means player is active
	
	public int PlayerID_2 = 0; // -||-
	
	public Vector<ServerThread> lobby = new Vector<ServerThread>(); // Vector for the threads // is not really neccessary since we have only two threads
	
	public ViewMap map = new ViewMap(1, 0); // Makes the Map // if first argument is 0 map is not visible / if 1 it is visible / the second parameter is the playerID
	
	private int p1x = 0; // player One on x axis
	
	private int p1y = 0; // the same for all the other variables
	
	private int p2x = 0;
	
	private int p2y = 0;
	
	private int c1x = 0;
	
	private int c1y = 0;
	
	private int c2x = 0;
	
	private int c2y = 0;
	
	public ServerThread PlayerOne = null; // First server thread instead of using lobby i have made just two variables for that
	
	public ServerThread PlayerTwo = null; 
	
	public boolean PlayerOneOnline = false; // When the player connects it becomes online
	
	public boolean PlayerTwoOnline = false;
	
	public boolean PlayerOneBoardOnline = false; // when the board is being checked and both boards are put into one the boath boards are set true
	
	public boolean PlayerTwoBoardOnline = false;
	
	AStar aStar = new AStar(); // This is The A* algorithm for pathfinding / mostly i copied that from stackoverflow with some changes
	
	private int testNumber = 1; // test number is a counter for some methods
	
	private Random rand = new Random(); // Radnsom number Generator
	
	public static int MAX_PLAYERS = 2;
	
	public boolean saveOperationFinished = false; // is set to true when both players are registered
	
	Hibernate save = new Hibernate(); // All the methods for printing and saving are in the Hibernate file
	
	int moveCount = 0; // amount of moves made
	
	public boolean p1_Mountain_1 = false; // is used for checking if a player is on mountin and moving properly
	
	public boolean p2_Mountain_1 = false;
	
	public Vector<UserRecords> users = new Vector<UserRecords>(); // I save all the moves and records into a vector before saving it with hibernate to the database // speeds up the process
	
	public Vector<CurrentGame> moves = new Vector<CurrentGame>();
	
	int[][] blocked; // blocked cells used for A* cells with water
	
	public boolean stopped = false; // if this is true both players stop playing
	
	public boolean logSet = false; // loging variable
	
	// Method for Creating the logger and also a file where this will be printed out
	
	public void setLog() {
		if(!logSet) {
			try {
			fh = new FileHandler("LogFile.log");
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		logSet = true;
	}
	
	//This is the core method where the Server starts
	//The server waits for a connection with accept()
	//When a connection is there it creates a thread and saves them
	
	public void runServer() throws IOException{
		ServerSocket serverSocket = new ServerSocket(PORT);
		while(true) {
			try {
				setLog();
				logger.info("Server is Ready and waiting for connection ...");
				Socket socket = serverSocket.accept();
				logger.info("Server is accepting connection ...");
				ServerThread thread = new ServerThread(socket, this);
				save(thread);
				logger.info("Thread started");
				thread.start();	
			} catch (IOException ioException) {
				serverSocket.close(); 
				ioException.printStackTrace();
				System.exit(0);
		}
	} 
		
}
	//Method for saving the threads so that the server knows what to send to what thread aka Player
	
	private void save(ServerThread thread)
	{
		if(!saveOperationFinished) {
			
			if(PlayerOne == null) {
				lobby.add(thread);
				PlayerOne = thread;
				PlayerOneOnline = true;
				return;
			}
			
			if(PlayerTwo == null) {
				lobby.add(thread);
				PlayerTwo = thread;
				PlayerTwoOnline = true;
				saveOperationFinished = true;
				return;
			}
		}
	}
	
	//Method for randomly generating a gold field
	
	public Message generateGold(Message message) {
		//4 Business Rule 
		//Gold is not placed on the Player Start Position
		boolean mapOne = false;
		boolean mapTwo = false;
		
		int randVarx;
		
		int randVary;
		
		while(!mapOne) {
			
			randVarx = rand.nextInt(4); // It just searches for a spot that is green aka land and with help of
            randVary = rand.nextInt(8); // random it finds a spot for it / for both Map parts
			
			if(map.cells[randVarx][randVary].getBackground().equals(Color.GREEN)) {
				message.xPositionPlayerTreasureOne = randVarx;
				message.yPositionPlayerTreasureOne = randVary;
				mapOne = true;
			}
			
			message.xPositionPlayerTreasureTwo = 1;
			message.yPositionPlayerTreasureTwo = 6;	
		}
		
		while(!mapTwo) {
			
			randVarx = rand.nextInt(4);
            randVary = rand.nextInt(8);
			
			if(map.cells[randVarx][randVary].getBackground().equals(Color.GREEN)) {
				message.xPositionPlayerTreasureTwo = randVarx;
				message.yPositionPlayerTreasureTwo = randVary;	
				mapTwo = true;
			}
		}
		
		return message;
	}
	
	// When both maps are online one player is set to start the game
	
	public void setFirstPlayer() {
		whatPlayer = PlayerID_1;
	}
	
	// Very important method where both maps are gathered together to create one map and send them to both players
	// and also update the player positions after every round and also used for saving files to the database
	
	public void updateBoard(Message message)
	{
	    // only for testing purposes
		logger.info("Board Is Being Updated");
		if(PlayerOneOnline)
		{
			logger.info("PlayerOneOnline");
			for(int i = 0; i < 4; i++)
			{
				for(int j = 0; j < 8; j++)
				{
					map.coordinates[i][j] = message.Map.coordinates[i][j];
				} // The coordinates tell what is the value of the field mountain water land - the server copies that values to keep track
			}
			p1x = message.Map.playerPos_x;
			p1y = message.Map.playerPos_y;
			c1x = message.Map.castlePos_x;
			c1y = message.Map.castlePos_y;
			PlayerOneOnline = false;
			PlayerOneBoardOnline = true;
		}
		
		if(PlayerTwoOnline)
		{
			logger.info("PlayerTwoOnline");
			for(int i = 4, i2 = 0; i < 8; i++,i2++) 
			{
				for(int j = 0; j < 8; j++)
				{
					map.coordinates[i][j] = message.Map.coordinates[i2][j];
				}
			}
			p2x = message.Map.playerPos_x;
			p2y = message.Map.playerPos_y;
			c2x = message.Map.castlePos_x;
			c2y = message.Map.castlePos_y;
			generateGold(message);
			map.exchangeBothMaps(PlayerID_1, PlayerID_2, p1x, p1y, p2x, p2y, c1x, c1y, c2x, c2y, message.xPositionPlayerTreasureOne, 
			message.yPositionPlayerTreasureOne, message.xPositionPlayerTreasureTwo, message.yPositionPlayerTreasureTwo);
			map.update();
			PlayerTwoOnline = false;
			PlayerTwoBoardOnline = true;
		}
		
		// In the method exchange maps all the values from player one are exchanged with the values from player two so that 
		// both clients can see both players on the map
		
		if(PlayerOneBoardOnline && PlayerTwoBoardOnline)
		{
			logger.info("Server sent new Map to Players");
			Message mapOut = new Message();
			mapOut.Map = map; 
			mapOut.lost_Player = message.lost_Player;
			mapOut.stopGame = message.stopGame;
			//mapOut.playersOnlineAndPlayerOneStarts = true;
			moveCount++;
			
			// in this method we look what player is on the turn 
			// and adequately update the final map that is to be sent back to both threads aka clients
			
			if(whatPlayer == PlayerID_1) {
				System.out.println("whatPlayer == 0");
				mapOut.PlayerID = PlayerID_1;
				mapOut.xPositionPlayerOne = message.xNewPos;
				mapOut.yPositionPlayerOne = message.yNewPos;
				mapOut.xPositionPlayerTwo = -99;
				mapOut.yPositionPlayerTwo = -99;
				mapOut.xPositionPlayerTreasureOne = map.Gold_x;
				mapOut.yPositionPlayerTreasureOne = map.Gold_y;
				mapOut.xPositionPlayerCastleOne = message.xPositionPlayerCastleOne;
				mapOut.yPositionPlayerCastleOne = message.xPositionPlayerCastleOne;
				mapOut.xNewPos = message.xNewPos;
				mapOut.yNewPos = message.yNewPos;
				mapOut.PlayerID_1 = PlayerID_1;
				mapOut.PlayerID_2 = PlayerID_2;
				mapOut.playersOnlineAndPlayerOneStarts = true;
				String move = "Position X : " + message.xNewPos + " Position Y : " + message.yNewPos + " ";
				String startPos = "Position X : " + message.xPositionPlayerCastleOne + " Position Y : " + message.yPositionPlayerCastleOne + " ";
				CurrentGame g = new CurrentGame(moveCount, startPos, "00", move, "N", "?", message.PlayerID);
				if(moves.isEmpty()) { moves.add(g); }
				if(moves.lastElement().PlayerID != g.PlayerID) {
					moves.add(g);
				}
				// values are being saved to a vector which is then at the end of the game being saved to the database
				// i found this way much faster and more efficient but also riskier / if the game crashes the data is lost
			}
			if(whatPlayer == PlayerID_2) {
			
				System.out.println("whatPlayer == 1");
				mapOut.PlayerID = PlayerID_2;
				mapOut.xPositionPlayerTwo = message.xNewPos;
				mapOut.yPositionPlayerTwo = message.yNewPos;
				mapOut.xPositionPlayerOne = -99;
				mapOut.yPositionPlayerOne = -99;
				mapOut.xPositionPlayerTreasureTwo = map.Gold_x2;
				mapOut.yPositionPlayerTreasureTwo = map.Gold_y2;
				mapOut.xPositionPlayerCastleTwo = message.xPositionPlayerCastleTwo;
				mapOut.yPositionPlayerCastleTwo = message.xPositionPlayerCastleTwo;
				mapOut.xNewPos = message.xNewPos;
				mapOut.yNewPos = message.yNewPos;
				mapOut.PlayerID_1 = PlayerID_1;
				mapOut.PlayerID_2 = PlayerID_2;
				String move = "Position X : " + message.xNewPos + " Position Y : " + message.yNewPos + " ";
				String startPos = "Position X : " + message.xPositionPlayerCastleTwo + " Position Y : " + message.yPositionPlayerCastleTwo + " ";
				CurrentGame g = new CurrentGame(moveCount, startPos, "00", move, "N", "?", message.PlayerID);
				if(moves.isEmpty()) { moves.add(g); }
				if(moves.lastElement().PlayerID != g.PlayerID) {
					moves.add(g);
				}
			}
			
			sendtoBothPlayersServer(mapOut);
		}
	}
	
	
	
	public boolean checkBoard(Message message) {
		
		boolean check = false;
		int countWater = 0;
		int countLand = 0;
		int countMountain = 0;
		//1 Business Rule
		//The entire first part is controling if there are any islands on the map the algorithm is trying to find a path to any land area, 
		//if it cannot find such a path for every field there is an island generated on the map
		int start_x = 0;
		int start_y = 0;
		
		blocked = new int[DIMENSION_X][DIMENSION_Y]; // we first try to find the block spaces by looking at all
		// spaces with coordinates 1 this means water 
		// and also count the amount of water land and mountain in order to check the map
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(message.Map.coordinates[i][j] == 1)
				{
					++countWater;
					blocked[i][j] = -1;
				}
				if(message.Map.coordinates[i][j] == 0)
				{
					++countLand;
				}
				if(message.Map.coordinates[i][j] == 2)
				{
					++countMountain;
				}
			}
		}
		// problem was that starting position was an illigal position
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(message.Map.coordinates[i][j] == 0 && start_x == 0 && start_y == 0)
				{
					start_x = i;
					start_y = j;
				}
			}
		}
		// here we test if all the other fields can be reached from one starting point
		// that can be just some random land field because if all land fields are reachable form one
		// land field that means that there are no islands on the map
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(message.Map.coordinates[i][j] == 0)
				{
					check = aStar.test(testNumber++, 8, 8, start_x, start_y, i, j, blocked); 
					if(!check) {
						message.lost_Player = message.PlayerID;
						message.stopGame = true;
						return false;
					}
				}
			}
		}
		//2 Business Rule
		//This part is cheking if there are more than 3 Water fields on the longer Card part
		int counter = 0;
		
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(message.Map.coordinates[i][j] == 1)
				{
					++counter;
					if(counter > 3) {
						message.lost_Player = message.PlayerID;
						message.stopGame = true;
						return false;
					}
				}
			}
			counter = 0;
		}
		
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(message.Map.coordinates[i][j] == 1)
				{
					++counter;
					if(counter > 3) {
						message.lost_Player = message.PlayerID;
						message.stopGame = true;
						return false;
					}
				}
			}
			counter = 0;
		}
		
		//3 Business Rule
		//check if the minimum amount of land, water and mountain fields is reached
		if(countLand < MIN_VALUE_LAND || countMountain < MIN_VALUE_MOUNTAIN || countWater < MIN_VALUE_WATER) {
			message.lost_Player = message.PlayerID;
			message.stopGame = true;
			return false;
		}
		
		return true;
	}
	
	
	
	/*
		There are two parts one is for checking the map and the other for checking the moves
		The moves can be easily checked in the method checkMove which calls all the other methods 
		checking if the player run into water or is outside the border etc.
		the rules can easily be modified in this central place or new rules can easily be added
	*/
	
	public boolean checkMove(Message message) {
		//The Business-Rules can be turned on or off here
	//	if(!checkWater(message)) return false;
	//	if(!checkRange(message)) return false;
		if(!checkMoveCount(message)) return false;
	//	if(!checkPlayerDirection(message)) return false;
	//	if(!checkIfMountain(message)) return false;
		
		return true;
	}
	
	public boolean checkWater(Message message) {
		//5 Business Rule
		//checking if the client moved onto water
		if(map.coordinates[message.xNewPos][message.yNewPos] == 1) {
			UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, 0);
			users.add(u);
			return false;
		}
		return true;
	}
	
	public boolean checkRange(Message message) {
		//6 Business Rule
		// chek if the player is still on the table
		if(message.xNewPos > DIMENSION_X || message.yNewPos > DIMENSION_Y) {
			UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, 0);
			users.add(u);
			return false;
		}
		return true;
	}
	
	public boolean checkMoveCount(Message message) {
		//7 Buseness Rule
		//check if player played more than 100 Moves
		if(moveCount>MAX_MOVES) {
			UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, 0);
			users.add(u);
			return false;
		}
		return true;
	}
	
	public boolean checkPlayerDirection(Message message) {
		//8 Business Rule
		//check if player moved right left forward backwards and not diagonal
		UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, 0);
		if(message.xPositionPlayerOne != -99 && message.yPositionPlayerOne != -99 && message.xPositionPlayerTwo != -99 && message.yPositionPlayerTwo != -99) {
		if(message.PlayerID == PlayerID_1) { //we logicaly assume that not both y and x can be changed at the same time since we can not move diagonaly
			/*if((((message.xNewPos == message.xPositionPlayerOne + 1) || (message.xNewPos == message.xPositionPlayerOne - 1))  && message.yNewPos != message.yPositionPlayerOne)
					|| (((message.yNewPos == message.yPositionPlayerOne + 1) || (message.yNewPos == message.yPositionPlayerOne - 1))  && message.xNewPos != message.xPositionPlayerOne)) 
				System.out.println("Direction ERROR PlayerID 1 : " + message.PlayerID);*/
			if(!aStar.test(testNumber++, 8, 8, message.xPositionPlayerOne, message.yPositionPlayerOne, message.xNewPos, message.yNewPos, blocked)) {
				users.add(u);
				return false;
			}	
		}
		
		if(message.PlayerID == PlayerID_2) {
			/*if((((message.xNewPos == message.xPositionPlayerTwo + 1) || (message.xNewPos == message.xPositionPlayerTwo - 1))  && message.yNewPos != message.yPositionPlayerTwo)
					|| (((message.yNewPos == message.yPositionPlayerTwo + 1) || (message.yNewPos == message.yPositionPlayerTwo - 1))  && message.xNewPos != message.xPositionPlayerTwo)) 
				System.out.println("Direction ERROR PlayerID 2 : " + message.PlayerID);*/
			if(!aStar.test(testNumber++, 8, 8, message.xPositionPlayerTwo, message.yPositionPlayerTwo, message.xNewPos, message.yNewPos, blocked))
				users.add(u);
				return false;		
		
			}
		
		}
		
		return true;
	}
	
	public boolean checkIfMountain(Message message) {
		//9 Business rule
		//Check if on mountain has to play two times
		UserRecords u = new UserRecords(message.PlayerID, 0, 0, 0, 0);
		if(message.xPositionPlayerOne != -99 && message.yPositionPlayerOne != -99 && message.xPositionPlayerTwo != -99 && message.yPositionPlayerTwo != -99) {
		if(message.PlayerID == PlayerID_1) {
			if(map.coordinates[message.xPositionPlayerOne][message.yPositionPlayerOne] == 2 && !p1_Mountain_1) {
				p1_Mountain_1 = true;
				return true;
			}
			if(map.coordinates[message.xPositionPlayerOne][message.yPositionPlayerOne] == 2 && p1_Mountain_1) {
				if(message.xNewPos != message.xPositionPlayerOne || message.yNewPos != message.xPositionPlayerOne) 
				p1_Mountain_1 = false;
				users.add(u);
				return false;
			}
		}
		if(message.PlayerID_2 == PlayerID_2) {
			if(map.coordinates[message.xPositionPlayerTwo][message.yPositionPlayerTwo] == 2 && !p2_Mountain_1) {
				p1_Mountain_1 = true;
				return true;
			}
			if(map.coordinates[message.xPositionPlayerTwo][message.yPositionPlayerTwo] == 2 && p2_Mountain_1) {
				if(message.xNewPos != message.xPositionPlayerTwo || message.yNewPos != message.xPositionPlayerTwo)
				p2_Mountain_1 = false;
				users.add(u);
				return false;
				}
			}
		
		}
		return true;
	}
	
	// This method checks which player is on the turn to play just by looking at the thread
	// if the thread that sent the request is the thread that the server marked for plying then
	// it is also his turn to play
	
	public boolean isPlayerTurnAndChangePlayer(ServerThread player)
	{
	
		if(PlayerOneBoardOnline && PlayerTwoBoardOnline) {
		
		if(whatPlayer == PlayerID_1 && player == PlayerOne) {
			whatPlayer = PlayerID_2;
			System.out.println(PlayerID_1 + "played");
			return true;
		}
		
		if(whatPlayer == PlayerID_2 && player == PlayerTwo) {
			whatPlayer = PlayerID_1;
			System.out.println(PlayerID_2 + "played");
			return true;
		}
		
	}
		
		logger.info("player requested to play but could not");
		return false;
	}
	
	
	// This method sends the new map to both players which es then being updated by the players
	// It atually sends a message which contains the map and all the positions
	
	public void sendtoBothPlayersServer(Message message)
	{
		if(!stopped) {
		
		if(message.stopGame) {
			stopped = true;
			PlayerOne.sendMessage(message);
			PlayerTwo.sendMessage(message);
			save.saveUser(users);
			save.saveCurrentGame(moves);
			save.print(PlayerID_1, PlayerID_2);
			return;
		}
		
			PlayerOne.sendMessage(message);
			PlayerTwo.sendMessage(message);
		}
		
	}
}
