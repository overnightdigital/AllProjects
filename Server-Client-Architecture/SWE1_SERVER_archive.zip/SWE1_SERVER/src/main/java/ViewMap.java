

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.io.Serializable;


public class ViewMap extends JFrame{
	
	private static final int DIMENSION_X = 8;
	
	private static final int DIMENSION_Y = 8;
	
	private static final int MAX_VALUE_MOUNTAIN = 6;
	
	private static final int MAX_VALUE_WATER = 8;
	
	private static final int MAX_VALUE_LAND = 18;
	
	private static final int MIN_VALUE_MOUNTAIN = 3;
	
	private static final int MIN_VALUE_WATER = 4;
	
	private static final int MIN_VALUE_LAND = 5;
	
	final static long serialVersionUID = 102;
	
	private boolean exchangedMaps = false;
	
	private Random rand = new Random();
	
	public int playerPos_x;
	
	public int playerPos_y;
	
	public int castlePos_x;
	
	public int castlePos_y;
	
	public int playerPos_x2;
	
	public int playerPos_y2;
	
	public int castlePos_x2;
	
	public int castlePos_y2;
	
	public int Gold_x = -99;
	
	public int Gold_y = -99;
	
	public int Gold_x2 = -99;
	
	public int Gold_y2 = -99;
	
	public int genMountain;
	
	public int genWater;
	
	public int genLand;
	
	private int randVar;
	
	public int PlayerID1 = 0;
	
	public int PlayerID2 = 0;

	private Container contents;
	
	public JButton[][] cells;
	
	//final static long serialVersionUID = 102;
	/*
	private ImageIcon water = new ImageIcon("water.png");//Does not show image in eclipse but works as executable jar file
	
	private ImageIcon land = new ImageIcon("land.png");
	
	private ImageIcon mountain = new ImageIcon("mountain.png");
	
	private ImageIcon player = new ImageIcon("ai.png");
	
	private ImageIcon castle = new ImageIcon("castle.png");
	*/
	public int[][] coordinates; // 0 steht fur land/ 1 fur wasser/ 2 fur berg/ 
	
	public ViewMap(int operator, int PlayerID){
		
		super("AI Player");
		
		if(PlayerID1 == 0) PlayerID1 = PlayerID;
		if(PlayerID2 == 0) PlayerID2 = PlayerID;
		
		cells = new JButton[DIMENSION_X][DIMENSION_Y];
		coordinates = new int[DIMENSION_X][DIMENSION_Y];
		
		contents = getContentPane();
		contents.setLayout(new GridLayout(DIMENSION_X,DIMENSION_Y));
		
		Generate_Random();
		Generate_Player();
		
		setSize(500, 500);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		if(operator == 0)
		{
			setVisible(false);
		}
		if(operator == 1)
		{
			setVisible(true);
		}
		
	}
	
	public void positionGold(int i, int j)
	{
		if(cells[i][j].getBackground().equals(Color.GREEN))
		{
			cells[i][j].setBackground(Color.YELLOW);
		}
	}
	
	public void exchangeBothPlayers(int player1_x, int player1_y, int player2_x, int player2_y)
	{
		playerPos_x = player1_x;
		
		playerPos_y = player1_y;
		
		playerPos_x2 = player2_x;
		
		playerPos_y2 = player2_y;
	}
	
	public void exchangeBothMaps(int PlayerID_1, int PlayerID_2, int player1_x, int player1_y, int player2_x, int player2_y, int castle1_x, int castle1_y, int castle2_x, int castle2_y, int gold_x, int gold_y, int gold_x2, int gold_y2)
	{
		System.out.println("Maps exchanged");
		
		PlayerID1 = PlayerID_1;
		
		PlayerID2 = PlayerID_2;
		
		playerPos_x = player1_x;
		
		playerPos_y = player1_y;
		
		castlePos_x = castle1_x;
		
		castlePos_y = castle1_y;
		
		playerPos_x2 = player2_x;
		
		playerPos_y2 = player2_y;
		
		castlePos_x2 = castle2_x;
		
		castlePos_y2 = castle2_y;
		
		Gold_x = gold_x;
		
		Gold_y = gold_y;
		
		Gold_x2 = gold_x2;
		
		Gold_y2 = gold_y2;
		
		exchangedMaps = true;
	}
	
	public void update()
	{
		for(int i = 0; i < DIMENSION_X; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(coordinates[i][j] == 0)
				{
					cells[i][j].setBackground(Color.GREEN);
				//	cells[i][j].setIcon(land);
				}
				else if(coordinates[i][j] == 1)
				{
					cells[i][j].setBackground(Color.BLUE);
				//	cells[i][j].setIcon(water);
				}
				else if(coordinates[i][j] == 2)
				{
					cells[i][j].setBackground(Color.DARK_GRAY);
				//	cells[i][j].setIcon(mountain);
				}
			}
		}
		
		if(Gold_x != -99 && Gold_y != -99 && Gold_x2 != -99 && Gold_y2 != -99) {
			cells[Gold_x][Gold_y].setBackground(Color.YELLOW);
			cells[Gold_x2][Gold_y2].setBackground(Color.YELLOW);
		}
		
	}
	
	
	public void updatePlayer()
	{
		
		if(playerPos_x == castlePos_x && playerPos_y == castlePos_y)
		{
			System.out.println("Test1");
			cells[castlePos_x][castlePos_y].setBackground(Color.RED);
		}
		
		if(exchangedMaps && (playerPos_x2 == castlePos_x2 && playerPos_y2 == castlePos_y2))
		{
			System.out.println("Test2");
			cells[castlePos_x2][castlePos_y2].setBackground(Color.RED);
		}
		
		if(playerPos_x != castlePos_x || playerPos_y != castlePos_y)
		{
			System.out.println("Test3");
			cells[castlePos_x][castlePos_y].setBackground(Color.RED);
			cells[playerPos_x][playerPos_y].setBackground(Color.BLACK);
		}
		
		if(exchangedMaps && (playerPos_x2 != castlePos_x2 || playerPos_y2 != castlePos_y2))
		{
			System.out.println("Test4");
			cells[castlePos_x2][castlePos_y2].setBackground(Color.RED);
			cells[playerPos_x2][playerPos_y2].setBackground(Color.BLACK);
		}
		
	}
	
	public void updateOnlyPlayer()
	{
		
			//if(playerPos_x == playerPos_x2 && playerPos_y == playerPos_y2) return;
		
		cells[playerPos_x][playerPos_y].setBackground(Color.BLACK);
		cells[playerPos_x2][playerPos_y2].setBackground(Color.BLACK);
	}
	
	
	public void changePlayerPos1(int i, int j)
	{
		playerPos_x = i;
		playerPos_y = j;
	}
	
	public void changePlayerPos2(int i, int j)
	{
		playerPos_x2 = i;
		playerPos_y2 = j;
	}
	
	public void Generate_Player()
	{
		
		for(int i = 2; i < DIMENSION_X/2; i++)
		{
			for(int j = 4; j < DIMENSION_Y; j++)
			{
				if(cells[i][j].getBackground().equals(Color.GREEN))  //if(cells[i][j].getIcon().equals(land))
				{
					cells[i][j].setBackground(Color.RED);
				//	cells[i][j].setIcon(castle);
					playerPos_x = i;
					playerPos_y = j;
					castlePos_x = i;
					castlePos_y = j;
					return;
				}
			}
			
		}	
		
		
		for(int i = 0; i < DIMENSION_X/2; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				if(cells[i][j].getBackground().equals(Color.GREEN)) // same thing
				{
					cells[i][j].setBackground(Color.RED);
				//	cells[i][j].setIcon(castle);
					playerPos_x = i;
					playerPos_y = j;
					castlePos_x = i;
					castlePos_y = j;
					return;
				}
			}
			
		}	
	}
	
	
	private void Generate_Random() 
	{
		
		genMountain = rand.nextInt(MAX_VALUE_MOUNTAIN) + MIN_VALUE_MOUNTAIN;
		genWater = rand.nextInt(MAX_VALUE_WATER) + MIN_VALUE_WATER;
		genLand = rand.nextInt(MAX_VALUE_LAND) + MIN_VALUE_LAND;
		
		int countMountain = 0;
		int countWater = 0;
		int countLand = 0;
		
		int waterSector1 = 0;
		int waterSector2 = 0;
		int waterSector3 = 0;
		
		for(int i = 0; i < DIMENSION_X; i++)
		{
			for(int j = 0; j < DIMENSION_Y; j++)
			{
				cells[i][j] = new JButton();
					
					cells[i][j].setBackground(Color.BLACK);
					contents.add(cells[i][j]);
				}
				
			}
		
		
			for(int i = 0; i < DIMENSION_X/2; i++)
				{
					for(int j = 0; j < (DIMENSION_Y); j++)
						{
							randVar = rand.nextInt(2);
							if(randVar == 1 && genWater > 0)
							{
								if((j == 0) && waterSector1 < 3) {
									cells[i][j].setBackground(Color.BLUE);
							//		cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector1++;
								}
								
								if((j == 4) && waterSector2 < 3) {
									cells[i][j].setBackground(Color.BLUE);
							//		cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector2++;
								}
								
								if((j == 7) && waterSector3 < 3) {
									cells[i][j].setBackground(Color.BLUE);
							//		cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector3++;
								}
					
							}
							if(randVar == 0 && genMountain > 0) {
								cells[i][j].setBackground(Color.DARK_GRAY);
							//	cells[i][j].setIcon(mountain);
								coordinates[i][j] = 2;
								genMountain--;
								countMountain++;
							}
							else if(randVar == 2 && genLand > 0 && countLand < MAX_VALUE_LAND)
							{
								cells[i][j].setBackground(Color.GREEN);
							//	cells[i][j].setIcon(land);
								coordinates[i][j] = 0;
								genLand--;
								countLand++;
							}
							
						}
				}
			
			for(int i = 0; i < DIMENSION_X/2; i++)
			{
				for(int j = 0; j < (DIMENSION_Y); j++)
					{
						if(cells[i][j].getBackground().equals(Color.BLACK)) { //same icon stuff
							if(countWater < MIN_VALUE_WATER)
							{
								if((j == 0) && waterSector1 < 3) {
									cells[i][j].setBackground(Color.BLUE);
								//	cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector1++;
								}
								
								if((j == 4) && waterSector2 < 3) {
									cells[i][j].setBackground(Color.BLUE);
								//	cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector2++;
								}
								
								if((j == 7) && waterSector3 < 3) {
									cells[i][j].setBackground(Color.BLUE);
								//	cells[i][j].setIcon(water);
									coordinates[i][j] = 1;
									countWater++;
									waterSector3++;
								}
								
							}
							else if(countMountain < MIN_VALUE_MOUNTAIN) 
							{
								cells[i][j].setBackground(Color.DARK_GRAY);
							//	cells[i][j].setIcon(mountain);
								coordinates[i][j] = 2;
								countMountain++;
							}
							else if(countLand < MIN_VALUE_LAND)
							{
								cells[i][j].setBackground(Color.GREEN);
							//	cells[i][j].setIcon(land);
								coordinates[i][j] = 0;
								countLand++;
							}
						}
					
					}
				
			}
			
			for(int i = 0; i < DIMENSION_X/2; i++)
			{
				for(int j = 0; j < DIMENSION_Y; j++)
				{
					if(cells[i][j].getBackground().equals(Color.BLACK)) { // same thing
						cells[i][j].setBackground(Color.GREEN);
					//	cells[i][j].setIcon(land);
						coordinates[i][j] = 0;
					}
					
					
				}
					
			}
			
			if(countLand < MIN_VALUE_LAND || countMountain < MIN_VALUE_MOUNTAIN || countWater < MIN_VALUE_WATER)
			{
				try {
				
					throw new Exception();
					
				}
				catch(Exception exception)
				{
					exception.printStackTrace();
					System.out.println("Map failed");
				}
			}
				
			
	}
		
}
