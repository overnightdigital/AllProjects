import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CurrentGame")
public class CurrentGame {
	
	@Id
	@Column(name="MoveID")
	int MoveID = 0;
	
	@Column(name="StartPos")
	String StartPos = "00";
	
	@Column(name="EndPos")
	String EndPos = "00";
	
	@Column(name="MovePlayed")
	String MovePlayed = " ";
	
	@Column(name="Direction")
	String Direction = "N";
	
	@Column(name="Discovery")
	String Discovery = " ";
	
	@Column(name ="PlayerID")
	int PlayerID = 0;
	
	CurrentGame() {}
	
	CurrentGame(int MoveID, String StartPos, String EndPos, String MovePlayed, String Direction, String Discovery, int PlayerID){
		this.MoveID = MoveID;
		this.StartPos = StartPos;
		this.EndPos = EndPos;
		this.MovePlayed = MovePlayed;
		this.Direction = Direction;
		this.Discovery = Discovery;
		this.PlayerID = PlayerID;
	}
	
	@Override
	public String toString() {
		return " - MoveID : " + MoveID + " | StartPos : " + StartPos + " | EndPos : " + EndPos + " | MovePlayed : " + MovePlayed + " | Direction : " + Direction + " | Discovery : " + Discovery + " | PlayerID : " + PlayerID + "-";
	}

}